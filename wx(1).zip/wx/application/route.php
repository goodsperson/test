<?php
use think\Route;
Route::rule([
	'api/:action'=>'index/Index/:action',//api
	'apii/:action'=>'index/Indexx/:action',//apii
	'api2/:action'=>'index/Gift/:action',//api2
]);

return [
    '__pattern__' => [
        'name' => '\w+',
    ],
    '[hello]'     => [
        ':id'   => ['index/hello', ['method' => 'get'], ['id' => '\d+']],
        ':name' => ['index/hello', ['method' => 'post']],
    ],

];
