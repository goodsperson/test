<?php
namespace app\index\controller;
use think\Request;
class Index{
    public function getOpenId()
    {
    	$code = input('get.code');
    	$mes = file_get_contents('https://api.weixin.qq.com/sns/jscode2session?appid=wx86505e805a9c3fc1&secret=962d3c8d7452ecc55de84d55b11b599d&js_code='.$code.'&grant_type=authorization_code');
        return $mes;
    }
}
