<?php
namespace app\index\controller;
use think\Request;
use think\Db;
use think\Validate;

class Indexx{

	//获取openid
    public function getOpenId()
    {
        if(request()->isPost()){
        	$code = input('post.code');
        	//唯一标示
            $openId = $this->getMes($code);
            if(empty($openId)){
                $arr = [
                    'state'=>300,
                    'success'=>0,
                    'mes'=>'用户不合法'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            $arr = [
                'state'=>200,
                'success'=>1,
                'mes'=>'获取成功',
                'openId' => $openId
            ];
            return json_encode($arr,JSON_UNESCAPED_UNICODE);
        }
    }

    //保存微信用户信息
    public function getUserImage()
    {
        if(request()->isPost()){
            $postData = input('post.');
            $openId = $postData['openId'];
            $userName = $postData['userName'];
            $arr= [
                'userName'=>$userName
            ];
            if (Db::name('totalpoints')->where('openId',$openId)->update($arr)) {
                $arr = [
                    'state'=>200,
                    'success'=>1,
                    'mes'=>'个人信息保存成功'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }else{
                $arr = [
                    'state'=>300,
                    'success'=>0,
                    'mes'=>'个人信息保存失败'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
        }
    }
    
    
    
    //初始化接口
    public function initNum(){

        if(request()->isPost()){
            //获取用户唯一标示
            $openId = input('post.openId');
            if(empty($openId)){
                $arr = [
                    'state'=>300,
                    'success'=>0,
                    'mes'=>'用户不合法'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            //判断是否存在
            $isPresence = Db::table('wccg_totalpoints')->where('openId',$openId)->find();
            $date = $this->getDate();
            if(empty($isPresence)){//不存在新增
                $data = [
                    'openId' => $openId, 
                    'cumPoints' => 0,
                    'remainPoints' => 0,
                    'gameNum' => 3,
                    'date'   => $date
                ];
                Db::table('wccg_totalpoints')->insert($data);
            }else{//存在，判断时间
                if($isPresence['date'] != $date){//如果时间不是今天，更新时间，初始化得红包次数
                    $data = [
                        'gameNum' => 3,
                        'date'   => $date,
                        'isShare'   => 0
                    ];
                    Db::table('wccg_totalpoints')->where('openId',$openId)->update($data);
                }
            }
            $arr = [
                'state'=>200,
                'success'=>1,
                'mes'=>'登录成功'
            ];
            return json_encode($arr,JSON_UNESCAPED_UNICODE);
        }
    }
    //获取游戏次数并判断
    public function getGameNnum(){
        if(request()->isPost()){
            $openId = input('post.openId');
            //$openId = $this->getMes($code);
            // if(empty($openId)){
            //     $arr = [
            //         'state'=>200,
            //         'success'=>0,
            //         'mes'=>'用户不合法'
            //     ];
            //     return json_encode($arr,JSON_UNESCAPED_UNICODE);
            // }
            $user = Db::table('wccg_totalpoints')->field('gameNum,school,name,profession,phone,isShare')->where('openId',$openId)->find();
            if(empty($user)){
                $arr = [
                    'state'=>200,
                    'success'=>0,
                    'mes'=>'用户不合法'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            $num = $user['gameNum'];
            $name = $user['name'];
            $school = $user['school'];
            $profession = $user['profession'];
            $phone = $user['phone'];
            $isShare = $user['isShare'];
            //次数为3
            if($num == 3){
                $arr = [
                    'state'=>200,
                    'success'=>3,
                    'mes'=>'直接进游戏'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            //次数为2
            if($num == 2){
                //是否分享
                if($isShare == 0){
                    $arr = [
                        'state'=>200,
                        'success'=>2,
                        'mes'=>'分享进游戏'
                    ];
                    return json_encode($arr,JSON_UNESCAPED_UNICODE);
                }
                if($isShare > 0){
                    $arr = [
                        'state'=>200,
                        'success'=>3,
                        'mes'=>'直接进游戏'
                    ];
                    return json_encode($arr,JSON_UNESCAPED_UNICODE);
                }
            }
            //次数为1
            if($num == 1){
                //是否填表
                if(!empty($user['name'])){//有填表
                    //是否二次分享
                    if($isShare > 1){
                        $arr = [
                            'state'=>200,
                            'success'=>3,
                            'mes'=>'直接进游戏'
                        ];
                        return json_encode($arr,JSON_UNESCAPED_UNICODE);
                    }
                    if($isShare < 2){
                        $arr = [
                            'state'=>200,
                            'success'=>2,
                            'mes'=>'分享进游戏'
                        ];
                        return json_encode($arr,JSON_UNESCAPED_UNICODE);
                    }
                }else{
                    $arr = [
                        'state'=>200,
                        'success'=>1,
                        'mes'=>'填表进游戏'
                    ];
                    return json_encode($arr,JSON_UNESCAPED_UNICODE);
                }
            }
            
            $arr = [
                'state'=>200,
                'success'=>-1,
                'mes'=>'游戏机会已用完'
            ];
            return json_encode($arr,JSON_UNESCAPED_UNICODE);
        }
    }
    //分享判断
    public function getPartakeNum(){
        if(request()->isPost()){
            $code = input('post.code');
            $openId = $this->getMes($code);
            if(empty($openId)){
                $arr = [
                    'state'=>200,
                    'success'=>0,
                    'mes'=>'用户不合法'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            $naisShare = Db::table('wccg_totalpoints')->field('name,isShare')->where('openId',$openId)->find();
            $isShare = (int)$naisShare['isShare'];
            $name = $naisShare['name'];
            if($isShare == 0){
                $isShare++;
                $data = [
                    'isShare' => $isShare
                ];
                Db::table('wccg_totalpoints')->where('openId',$openId)->update($data);
                $arr = [
                    'state'=>200,
                    'success'=>1,
                    'mes'=>'游戏次数+1'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            if($isShare == 1 && !empty($name)){
                $isShare++;
                $data = [
                    'isShare' => $isShare
                ];
                Db::table('wccg_totalpoints')->where('openId',$openId)->update($data);

                $arr = [
                    'state'=>200,
                    'success'=>1,
                    'mes'=>'游戏次数+1'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            $arr = [
                'state'=>200,
                'success'=>2,
                'mes'=>'分享成功'
            ];
            return json_encode($arr,JSON_UNESCAPED_UNICODE);
        }
    }

    //玩游戏后发过来的
    public function getPlay()
    {
        if(request()->isPost()){
            Db::startTrans();
            try {
                $postData = input('post.');
                $score = $postData['score'];
                $openid = $postData['openId'];
                $dateNow = $this->getDate();
                $re = Db::name('totalpoints')->where('openId',$openid)->find();
                if (!empty($re)) {
                    if ($re['gameNum'] > 0 && $re['gameNum'] < 4) {
                        //更总积分记录表
                        if($score['time'] > 0.00 && $score['time'] <= 30.00 ){
                            $jf = 50;
                        }else if($score['time'] > 30.00 && $score['time'] <= 40.00 ){
                            $jf = 45;
                        } else if($score['time'] > 40.00 && $score['time'] <= 50.00 ){
                            $jf = 40;
                        } else if($score['time'] > 50.00 && $score['time'] <= 60.00 ){
                            $jf = 35;
                        } else if($score['time'] > 60.00 && $score['time'] <= 70.00 ){
                            $jf = 30;
                        } else if($score['time'] > 70.00 && $score['time'] <= 80.00 ){
                            $jf = 25;
                        } else if($score['time'] > 80.00 && $score['time'] <= 90.00 ){
                            $jf = 20;
                        } else if($score['time'] > 90.00  ){
                            $jf = 0;
                        } 
                        $map = [
                            'cumPoints'=>$re['cumPoints']+$jf,//总积分
                            'remainPoints'=>$re['remainPoints']+$jf,//剩余积分
                            'gameNum'=>$re['gameNum']-1//游戏次数
                        ];
                        if ($score['time'] <= $re['minPassTime'] || empty($re['minPassTime'] )) {//游戏时间少于记录时间
                            $map['minPassTime'] =  $score['time'];//最短时间
                            $map['minClickNum'] =  $score['click'];//最短时间内最少点击次数
                        }
                        $maps = [
                            'openId' => $openid,
                            'integral' => $jf,
                            'date' => $dateNow
                        ];
                        if (Db::name('totalpoints')->where('openId',$openid)->update($map) && Db::name('pointrecord')->insert($maps)) {
                            
                            $arr = [
                                'state'=>200,
                                'success'=>1,
                                'mes'=>'游戏结束',
                                'jf'=>$jf
                            ];
                        }else{
                            $arr = [
                                'state'=>300,
                                'success'=>-1,
                                'mes'=>'游戏结束,游戏记录保存不成功'
                            ];
                        }
                    }else{
                        $arr = [
                        'state'=>300,
                        'success'=>2,
                        'mes'=>'游戏次数已经用完'
                        ];
                    }
                }else{
                    $arr = [
                        'state'=>300,
                        'success'=>0,
                        'mes'=>'请先登录再开始游戏'
                    ];
                }
                Db::commit();
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            } catch (\Exception $e) {
                //回滚事物
                Db::rollback();
                $arr = [
                    'state'=>200,
                    'success'=>-10,
                    'mes'=>'游戏结束,游戏记录保存不成功'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
        }
    }

    //获取学生填写的信息，保存到数据库
    public function getInfo()
    {
        if(request()->isPost()){
            $validate = new Validate([
                'name'=>'require',
                'school'=>'require',
                'profession'=>'require',
                'phone'=>'require|number|length:11'
            ]);
            //获取提交的信息
            $postData = input('post.');
            if(!$validate->check($postData['formData'])){
                $arr = [
                        'state'=>200,
                        'success'=>5,
                        'mes'=>'参数格式不正确'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
            $code = $postData['code'];
            $info = $postData['formData'];
            $openid = $this->getMes($code);
            $re = Db::name('totalpoints')->where('openId',$openid)->find();
            if (!empty($re)) {
                if (empty($re['name']) && $re['isShare'] == 1) {
                    $info['isShare'] = 2;
                    if (Db::name('totalpoints')->where('openId',$openid)->update($info)) {
                        $arr = [
                            'state'=>200,
                            'success'=>1,
                            'mes'=>'信息保存成功'
                        ];
                        return json_encode($arr,JSON_UNESCAPED_UNICODE);
                    }else{
                        $arr = [
                            'state'=>200,
                            'success'=>2,
                            'mes'=>'信息保存失败'
                        ];
                        return json_encode($arr,JSON_UNESCAPED_UNICODE);
                    }
                }else{
                    $arr = [
                        'state'=>200,
                        'success'=>3,
                        'mes'=>'信息已存在或还没分享'
                    ];
                    return json_encode($arr,JSON_UNESCAPED_UNICODE);
                }
            }else{
                $arr = [
                    'state'=>200,
                    'success'=>4,
                    'mes'=>'先登录再填写信息'
                ];
                return json_encode($arr,JSON_UNESCAPED_UNICODE);
            }
        }
    }

    //积分排行
    public function getIntervals(){

        $res = Db::name('totalpoints')->field('openId,cumPoints,userName')->order('cumPoints desc')->limit(10)->select();
        
        if(!empty($res)){
            $arr = [];
            $result = [];
            $num = 1;
            foreach($res as $key => $val){
                $arr = json_decode($val['userName'],256);
                $arr['cumPoints'] = $val['cumPoints'];
                $arr['num'] = $num;
                $num++;
                $result[] = $arr;

            }
        
        }else {
            return json_encode(['code'=>404,'status'=>'fail','msg'=>'暂无数据信息！']);
        }
        
        return json_encode(['code'=>200,'status'=>'success','data'=>$result]);
    }

    //游戏排行
    public function getGames(){
        $res = Db::name('totalpoints')->field('userName,minClickNum,minPassTime')->where('minPassTime is not null')->order('minPassTime asc')->order('minClickNum asc')->limit(10)->select();
        if(!empty($res)){
            $arr = [];
            $result = [];
            $num = 1;
            foreach($res as $key => $val){
                $arr = json_decode($val['userName'],256);
                $arr['minClickNum'] = $val['minClickNum'];
                $arr['minPassTime'] = $val['minPassTime'];
                $arr['num'] = $num;
                $num++;
                $result[] = $arr;

            }
        
        }else {
            return json_encode(['code'=>404,'status'=>'fail','msg'=>'暂无数据信息！']);
        }
        
        return json_encode(['code'=>200,'status'=>'success','data'=>$result]);
        
    }

    //获取openId用户唯一标示
    public function getMes($code){
        $v = json_decode(file_get_contents('https://api.weixin.qq.com/sns/jscode2session?appid=wx86505e805a9c3fc1&secret=962d3c8d7452ecc55de84d55b11b599d&js_code='.$code.'&grant_type=authorization_code'),true);
        foreach ($v as $key => $value) {
            if($key === 'openid'){
                return $value;
            }
        }
    }
    //获取当前日期
    public function getDate(){
        return date("Y-m-d",time());
    }
}
