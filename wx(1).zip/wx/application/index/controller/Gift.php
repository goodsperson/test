<?php
namespace app\index\controller;
use think\Request;
use think\Db;
class Gift{
	//获取openid
    public function getOpenId()
    {
    	$code = input('get.code');
    	$mes = file_get_contents('https://api.weixin.qq.com/sns/jscode2session?appid=wx86505e805a9c3fc1&secret=962d3c8d7452ecc55de84d55b11b599d&js_code='.$code.'&grant_type=authorization_code');
        return $mes;
    }

    //获取礼品
    public function getGift(){
    	$list = Db::name('gift')->select();
    	return json_encode($list);
    }

    /**
     * /记录兑换记录
     * 返回参数
     * 200  成功
     * 201  参数不全
     * 202  没有信息
     * 203  数据库操作失败
     * 204  积分不够
     */
    public function Exchange(){
    	if(request()->isPost()){
    		Db::startTrans();
    		try{
    			//获取传递信息
    			$data = input('post.');
    			//验证信息准确性
    			if(empty($data['openId']) || empty($data['id'])){
    				throw new \Exception("参数信息不全", 201);
    			}
    			//获取礼物信息和验证是否存在
    			$gift = Db::name('gift')->field('name,points')->where('id',$data['id'])->find();
    			if(empty($gift)){
    				throw new \Exception("没有此礼物信息", 202);
    			}
    			//验证用户信息是否合法或存在
    			$user = Db::name('totalpoints')->where('openId',$data['openId'])->find();
    			if(empty($user)){
    				throw new \Exception("没有此用户信息", 202);
    			}
    			//验证积分是否足够
    			if($user['remainPoints'] < $gift['points']){
    				throw new \Exception("积分不够", 204);
    			}else{
    				$points = $user['remainPoints'] - $gift['points'];//计算过后的剩余积分
    			}
    			//生成兑换记录并改变个人总积分
    			$randomcode = $this->RandomKeys(10);
    			$list = [
    				'openId'       =>   $data['openId'],
    				'points'       =>   $gift['points'],
    				'gift'         =>   $gift['name'],
    				'exchangeCode' =>   $randomcode,
    				'date'         =>   date('Y-m-d',time())
    			];
    			if(!Db::name('giftrecord')->insert($list)){
    				throw new \Exception("数据处理失败1", 203);
    			}
    			if(Db::name('totalpoints')->where('openId',$data['openId'])->update(['remainPoints'=>$points])===false){
    				throw new \Exception("数据处理失败2", 203);
    			}
    			//成功返回信息
    			$status = 200;
    			$mes = 'ok';
    			$code = $randomcode;
    		}catch(\Exception $e) {
	            Db::rollback();
	            $status = $e->getCode();
    			$mes = $e->getMessage();
    			$code = '';
	        }
            exit(json_encode(array('status'=>$status,'mes'=>$mes,'code'=>$code)));
    	}
    }

    /**
     * 随机生成兑换码
     * 返回string
     */
    public function RandomKeys($length){
   		$output='';
   		$pattern = '1234567890ABCDEFGHIJKLOMNOPQRSTUVWXYZ';
	   	for ($a = 0; $a<$length; $a++) {
	       $output .= $pattern{mt_rand(0,35)};
	    }
	    return $output;
	}

    /**
     * 获取用户信息
     * 返回array
     */
    public function getInfo(){
        if(request()->isPost()){
            $openid = input('post.openId');
            //用户信息
            $user = Db::name('totalpoints')->field('openId,cumPoints,remainPoints,userName')->where('openId',$openid)->find();
            if(empty($user)){
                exit(json_encode(array('status'=>202,'mes'=>'没有此用户')));
            }
            $avatarUrl = json_decode($user['userName'],true)['avatarUrl'];
            //积分记录
            $pointrecord = Db::name('pointrecord')->field('integral,date')->where('openId',$openid)->select();
            //兑换记录
            $giftrecord = Db::name('giftrecord')->field('gift,exchangeCode')->where('openId',$openid)->select();
            exit(json_encode(array('status'=>200,'mes'=>'ok','user'=>$user,'avatarUrl'=>$avatarUrl,'pointrecord'=>$pointrecord,'giftrecord'=>$giftrecord)));
        }else{
            exit(json_encode(array('status'=>500,'mes'=>'请求错误')));
        }
    }
}
